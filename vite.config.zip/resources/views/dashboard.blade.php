@extends('layout.layout')

@section('content')

                <!--<h1>Welcome, {{ Auth::user()->name }}!</h1>
                <p>You are now logged in to your account.</p>

                <form action="/logout" method="POST">
                    @csrf
                    <button>Logout</button>
                </form>-->
<div class="dashboard">
    
    <div class="main-content">
    </div>
</div>

@endsection