

<?php $__env->startSection('content'); ?>
 <img src="<?php echo e(Auth::user()->profile_photo 
            ? asset('profile_photos/' . Auth::user()->profile_photo)
            : asset('default-pfp.png')); ?>"
     width="120" height="120" style="border-radius: 50%; object-fit: cover;">

<form action="<?php echo e(route('settings.update.photo')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <label>New Profile Photo:</label><br>
    <input type="file" name="profile_photo" accept="image/*" required>

    <br><br>

    <button type="submit">Update Photo</button>
</form>
<a href="/dashboard" class="btn btn-primary">
    ← Back to Dashboard
</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ferrie\Desktop\laravel-projects\celo\resources\views/settings.blade.php ENDPATH**/ ?>