<?php $__env->startSection('content'); ?>

                <!--<h1>Welcome, <?php echo e(Auth::user()->name); ?>!</h1>
                <p>You are now logged in to your account.</p>

                <form action="/logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <button>Logout</button>
                </form>-->
<div class="dashboard">
    
    <div class="main-content">
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ferrie\Desktop\laravel-projects\celo\resources\views/dashboard.blade.php ENDPATH**/ ?>